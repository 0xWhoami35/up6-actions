<?php
defined('_JEXEC') or die();
class pwn extends Lomart\Plugin\Content\Up\Extension\Up {
    function init(){ return true; }
    function run(){ return ''; }
}
